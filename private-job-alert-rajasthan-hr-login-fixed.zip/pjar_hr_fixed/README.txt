PRIVATE JOB ALERT RAJASTHAN - HR LOGIN FIXED

1. Upload index.html to GitHub and replace the old index.html.
2. Keep the same Supabase project.
3. If HR tables/policies are not already installed, run supabase_hr_setup.sql once in Supabase SQL Editor.
4. Open the website and tap HR Login.
5. New HR: Create HR Account. Existing HR: enter email/password and Login.

Important: The publishable Supabase key is intended for browser use. Never put a secret/service-role key in index.html.
