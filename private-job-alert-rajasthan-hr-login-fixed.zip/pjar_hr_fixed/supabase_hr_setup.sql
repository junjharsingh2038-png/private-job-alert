-- PRIVATE JOB ALERT RAJASTHAN
-- Secure HR/company setup for Supabase
-- Run this in Supabase SQL Editor AFTER backing up existing data.

create extension if not exists pgcrypto;

create table if not exists public.hr_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  company_name text not null,
  contact_name text,
  phone text,
  email text,
  location text,
  logo_url text,
  created_at timestamptz not null default now()
);

alter table public.jobs add column if not exists owner_id uuid references auth.users(id) on delete cascade;
alter table public.jobs add column if not exists company_name text;
alter table public.jobs add column if not exists company_logo text;

alter table public.hr_profiles enable row level security;
alter table public.jobs enable row level security;

drop policy if exists "public can view jobs" on public.jobs;
create policy "public can view jobs" on public.jobs
for select to anon, authenticated using (true);

drop policy if exists "hr can insert own jobs" on public.jobs;
create policy "hr can insert own jobs" on public.jobs
for insert to authenticated
with check (owner_id = auth.uid());

drop policy if exists "hr can update own jobs" on public.jobs;
create policy "hr can update own jobs" on public.jobs
for update to authenticated
using (owner_id = auth.uid())
with check (owner_id = auth.uid());

drop policy if exists "hr can delete own jobs" on public.jobs;
create policy "hr can delete own jobs" on public.jobs
for delete to authenticated
using (owner_id = auth.uid());

drop policy if exists "hr can read own profile" on public.hr_profiles;
create policy "hr can read own profile" on public.hr_profiles
for select to authenticated
using (id = auth.uid());

drop policy if exists "hr can create own profile" on public.hr_profiles;
create policy "hr can create own profile" on public.hr_profiles
for insert to authenticated
with check (id = auth.uid());

drop policy if exists "hr can update own profile" on public.hr_profiles;
create policy "hr can update own profile" on public.hr_profiles
for update to authenticated
using (id = auth.uid())
with check (id = auth.uid());

-- Helpful indexes
create index if not exists jobs_owner_id_idx on public.jobs(owner_id);
create index if not exists jobs_created_at_idx on public.jobs(created_at desc);
